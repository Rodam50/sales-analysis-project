"""
Sales Data Analysis — Python Script
====================================
This script loads the sales CSV, cleans it, and produces key business insights.
Run: python scripts/analyze_sales.py
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import os

# ── Setup ──────────────────────────────────────────────────────────
os.makedirs("outputs", exist_ok=True)
sns.set_theme(style="whitegrid", palette="muted")
plt.rcParams["figure.dpi"] = 120

# ── STEP 1: Load the Data ──────────────────────────────────────────
print("=" * 55)
print("  SALES DATA ANALYSIS REPORT")
print("=" * 55)

df = pd.read_csv("data/sales_data.csv", parse_dates=["date"])

print(f"\n📂 Dataset loaded: {df.shape[0]} rows × {df.shape[1]} columns")
print("\n--- First 5 rows ---")
print(df.head())
print("\n--- Data types ---")
print(df.dtypes)
print("\n--- Missing values ---")
print(df.isnull().sum())

# ── STEP 2: Add Derived Columns ────────────────────────────────────
df["year"]    = df["date"].dt.year
df["month"]   = df["date"].dt.month
df["month_name"] = df["date"].dt.strftime("%b")
df["quarter"] = df["date"].dt.quarter.map({1:"Q1", 2:"Q2", 3:"Q3", 4:"Q4"})

# ── STEP 3: Summary Statistics ─────────────────────────────────────
print("\n\n📊 SUMMARY STATISTICS")
print("-" * 40)
total_revenue  = df["total_sale"].sum()
total_orders   = df["order_id"].nunique()
avg_order_val  = df["total_sale"].mean()
total_units    = df["quantity"].sum()

print(f"  Total Revenue   : ${total_revenue:>12,.2f}")
print(f"  Total Orders    : {total_orders:>12,}")
print(f"  Avg Order Value : ${avg_order_val:>12,.2f}")
print(f"  Total Units Sold: {total_units:>12,}")

# ── STEP 4: Revenue by Category ───────────────────────────────────
print("\n\n📦 REVENUE BY CATEGORY")
print("-" * 40)
cat_rev = (df.groupby("category")["total_sale"]
             .sum()
             .sort_values(ascending=False)
             .reset_index())
cat_rev.columns = ["Category", "Total Revenue"]
cat_rev["Share %"] = (cat_rev["Total Revenue"] / total_revenue * 100).round(1)
print(cat_rev.to_string(index=False))

# ── STEP 5: Top 5 Products ────────────────────────────────────────
print("\n\n🏆 TOP 5 PRODUCTS BY REVENUE")
print("-" * 40)
top_products = (df.groupby("product")["total_sale"]
                  .sum()
                  .sort_values(ascending=False)
                  .head(5)
                  .reset_index())
top_products.columns = ["Product", "Revenue"]
print(top_products.to_string(index=False))

# ── STEP 6: Revenue by Region ─────────────────────────────────────
print("\n\n🌍 REVENUE BY REGION")
print("-" * 40)
region_rev = (df.groupby("region")["total_sale"]
                .sum()
                .sort_values(ascending=False)
                .reset_index())
region_rev.columns = ["Region", "Revenue"]
print(region_rev.to_string(index=False))

# ── STEP 7: Top Sales Reps ────────────────────────────────────────
print("\n\n🥇 TOP SALES REPRESENTATIVES")
print("-" * 40)
rep_perf = (df.groupby("sales_rep")
              .agg(total_revenue=("total_sale","sum"),
                   total_orders=("order_id","count"))
              .sort_values("total_revenue", ascending=False)
              .reset_index())
print(rep_perf.to_string(index=False))

# ── STEP 8: Monthly Revenue Trend ────────────────────────────────
monthly = (df.groupby(["year","month"])["total_sale"]
             .sum()
             .reset_index()
             .sort_values(["year","month"]))
monthly["period"] = monthly["year"].astype(str) + "-" + monthly["month"].astype(str).str.zfill(2)

# ── STEP 9: Visualisations ────────────────────────────────────────
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle("Sales Analysis Dashboard — 2023–2024", fontsize=16, fontweight="bold", y=1.01)

# Chart 1: Monthly Revenue Trend
ax1 = axes[0, 0]
ax1.plot(monthly["period"], monthly["total_sale"], marker="o", linewidth=2, color="#2563EB")
ax1.fill_between(range(len(monthly)), monthly["total_sale"], alpha=0.1, color="#2563EB")
ax1.set_xticks(range(0, len(monthly), 3))
ax1.set_xticklabels(monthly["period"].iloc[::3], rotation=45, ha="right", fontsize=8)
ax1.set_title("Monthly Revenue Trend")
ax1.set_ylabel("Revenue ($)")
ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))

# Chart 2: Revenue by Category (bar)
ax2 = axes[0, 1]
colors = ["#2563EB", "#16A34A", "#DC2626"]
bars = ax2.bar(cat_rev["Category"], cat_rev["Total Revenue"], color=colors)
ax2.set_title("Revenue by Product Category")
ax2.set_ylabel("Revenue ($)")
ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
for bar, val in zip(bars, cat_rev["Total Revenue"]):
    ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 500,
             f"${val:,.0f}", ha="center", va="bottom", fontsize=8, fontweight="bold")

# Chart 3: Top Products (horizontal bar)
ax3 = axes[1, 0]
ax3.barh(top_products["Product"], top_products["Revenue"], color="#7C3AED")
ax3.set_title("Top 5 Products by Revenue")
ax3.set_xlabel("Revenue ($)")
ax3.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
ax3.invert_yaxis()

# Chart 4: Revenue by Region (pie)
ax4 = axes[1, 1]
ax4.pie(region_rev["Revenue"], labels=region_rev["Region"],
        autopct="%1.1f%%", startangle=140,
        colors=["#2563EB","#16A34A","#DC2626","#F59E0B","#8B5CF6"])
ax4.set_title("Revenue Share by Region")

plt.tight_layout()
plt.savefig("outputs/sales_dashboard.png", bbox_inches="tight")
print("\n\n✅ Dashboard chart saved → outputs/sales_dashboard.png")
plt.close()

print("\n✅ Analysis complete!\n")
