import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

# Set seed for reproducibility
np.random.seed(42)
random.seed(42)

# ─── Configuration ───────────────────────────────────────────────
NUM_RECORDS = 1000
START_DATE = datetime(2023, 1, 1)
END_DATE = datetime(2024, 12, 31)

PRODUCTS = {
    "Laptop Pro":      {"category": "Electronics",  "base_price": 1200},
    "Wireless Mouse":  {"category": "Accessories",  "base_price": 35},
    "USB-C Hub":       {"category": "Accessories",  "base_price": 55},
    "Monitor 27in":    {"category": "Electronics",  "base_price": 350},
    "Mechanical Keyboard": {"category": "Accessories", "base_price": 110},
    "Webcam HD":       {"category": "Electronics",  "base_price": 90},
    "Desk Lamp LED":   {"category": "Office",       "base_price": 45},
    "Ergonomic Chair": {"category": "Office",       "base_price": 280},
    "Standing Desk":   {"category": "Office",       "base_price": 450},
    "Noise Cancelling Headphones": {"category": "Electronics", "base_price": 250},
}

REGIONS = ["North", "South", "East", "West", "Central"]
SALES_REPS = [
    "Alice Nakamura", "Brian Osei", "Clara Mensah", "David Kimani",
    "Eva Lwanga", "Felix Mubiru", "Grace Atieno", "Henry Banda",
    "Irene Zawedde", "James Okello"
]

# ─── Generate Data ────────────────────────────────────────────────
records = []
for i in range(1, NUM_RECORDS + 1):
    product_name = random.choice(list(PRODUCTS.keys()))
    product_info = PRODUCTS[product_name]
    base_price = product_info["base_price"]

    # Slight price variation (+/- 10%)
    unit_price = round(base_price * random.uniform(0.90, 1.10), 2)
    quantity = random.randint(1, 15)
    discount_pct = random.choice([0, 0, 0, 5, 10, 15, 20])  # 0 is most common
    discount_amount = round(unit_price * quantity * (discount_pct / 100), 2)
    total_sale = round(unit_price * quantity - discount_amount, 2)

    # Random date within range
    delta = (END_DATE - START_DATE).days
    sale_date = START_DATE + timedelta(days=random.randint(0, delta))

    records.append({
        "order_id": f"ORD-{i:04d}",
        "date": sale_date.strftime("%Y-%m-%d"),
        "product": product_name,
        "category": product_info["category"],
        "region": random.choice(REGIONS),
        "sales_rep": random.choice(SALES_REPS),
        "quantity": quantity,
        "unit_price": unit_price,
        "discount_pct": discount_pct,
        "discount_amount": discount_amount,
        "total_sale": total_sale,
    })

df = pd.DataFrame(records).sort_values("date").reset_index(drop=True)
df.to_csv("data/sales_data.csv", index=False)
print(f"✅ Generated {len(df)} sales records → data/sales_data.csv")
print(df.head())
