-- ============================================================
--  SALES DATA ANALYSIS — SQL QUERIES
--  Database: SQLite (via Python's sqlite3 module)
--  Run with: python sql/run_queries.py
-- ============================================================


-- ── QUERY 1: Overall Business Summary ──────────────────────
-- What is our total performance at a glance?

SELECT
    COUNT(DISTINCT order_id)          AS total_orders,
    ROUND(SUM(total_sale), 2)         AS total_revenue,
    ROUND(AVG(total_sale), 2)         AS avg_order_value,
    SUM(quantity)                     AS total_units_sold,
    ROUND(AVG(discount_pct), 1)       AS avg_discount_pct
FROM sales;


-- ── QUERY 2: Revenue by Category ───────────────────────────
-- Which product category makes us the most money?

SELECT
    category,
    COUNT(order_id)                                        AS num_orders,
    SUM(quantity)                                          AS units_sold,
    ROUND(SUM(total_sale), 2)                              AS total_revenue,
    ROUND(SUM(total_sale) * 100.0 / SUM(SUM(total_sale))
          OVER (), 1)                                      AS revenue_share_pct
FROM sales
GROUP BY category
ORDER BY total_revenue DESC;


-- ── QUERY 3: Top 5 Best-Selling Products ────────────────────
-- Which specific products drive the most revenue?

SELECT
    product,
    category,
    SUM(quantity)                  AS units_sold,
    ROUND(SUM(total_sale), 2)      AS total_revenue,
    ROUND(AVG(unit_price), 2)      AS avg_unit_price
FROM sales
GROUP BY product, category
ORDER BY total_revenue DESC
LIMIT 5;


-- ── QUERY 4: Monthly Revenue Trend ──────────────────────────
-- How does revenue change month by month?

SELECT
    STRFTIME('%Y', date)        AS year,
    STRFTIME('%m', date)        AS month,
    COUNT(order_id)             AS num_orders,
    ROUND(SUM(total_sale), 2)   AS monthly_revenue
FROM sales
GROUP BY year, month
ORDER BY year, month;


-- ── QUERY 5: Revenue by Region ──────────────────────────────
-- Which geographic region performs best?

SELECT
    region,
    COUNT(DISTINCT order_id)       AS num_orders,
    ROUND(SUM(total_sale), 2)      AS total_revenue,
    ROUND(AVG(total_sale), 2)      AS avg_order_value
FROM sales
GROUP BY region
ORDER BY total_revenue DESC;


-- ── QUERY 6: Sales Rep Performance Leaderboard ──────────────
-- Who are our top-performing salespeople?

SELECT
    sales_rep,
    COUNT(order_id)                AS total_orders,
    ROUND(SUM(total_sale), 2)      AS total_revenue,
    ROUND(AVG(total_sale), 2)      AS avg_deal_size,
    SUM(quantity)                  AS units_sold
FROM sales
GROUP BY sales_rep
ORDER BY total_revenue DESC;


-- ── QUERY 7: Year-over-Year Comparison ─────────────────────
-- Did we grow from 2023 to 2024?

SELECT
    STRFTIME('%Y', date)          AS year,
    COUNT(order_id)               AS total_orders,
    ROUND(SUM(total_sale), 2)     AS total_revenue,
    ROUND(AVG(total_sale), 2)     AS avg_order_value
FROM sales
GROUP BY year
ORDER BY year;


-- ── QUERY 8: Discount Impact Analysis ──────────────────────
-- Are discounts hurting or helping sales volume?

SELECT
    discount_pct,
    COUNT(order_id)                AS num_orders,
    ROUND(AVG(quantity), 1)        AS avg_quantity,
    ROUND(AVG(total_sale), 2)      AS avg_order_value,
    ROUND(SUM(total_sale), 2)      AS total_revenue
FROM sales
GROUP BY discount_pct
ORDER BY discount_pct;


-- ── QUERY 9: Best Month Per Region ──────────────────────────
-- For each region, what was their single best month?

SELECT
    region,
    year,
    month,
    monthly_revenue
FROM (
    SELECT
        region,
        STRFTIME('%Y', date)       AS year,
        STRFTIME('%m', date)       AS month,
        ROUND(SUM(total_sale), 2)  AS monthly_revenue,
        RANK() OVER (
            PARTITION BY region
            ORDER BY SUM(total_sale) DESC
        )                          AS rnk
    FROM sales
    GROUP BY region, year, month
)
WHERE rnk = 1
ORDER BY monthly_revenue DESC;


-- ── QUERY 10: High-Value Orders (Above Average) ─────────────
-- Which orders were significantly above our average?

SELECT
    order_id,
    date,
    product,
    sales_rep,
    region,
    total_sale
FROM sales
WHERE total_sale > (SELECT AVG(total_sale) * 2 FROM sales)
ORDER BY total_sale DESC
LIMIT 10;
