"""
Run SQL Queries on Sales Data
==============================
This script loads the CSV into a SQLite database in memory,
then runs all SQL queries and prints the results.

Run: python sql/run_queries.py
"""

import sqlite3
import pandas as pd
import os

# ── Load CSV into SQLite ───────────────────────────────────────────
df = pd.read_csv("data/sales_data.csv")
conn = sqlite3.connect(":memory:")   # in-memory database (no file needed)
df.to_sql("sales", conn, index=False, if_exists="replace")

def run_query(title, sql):
    """Helper to run a query and print formatted results."""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)
    result = pd.read_sql_query(sql, conn)
    print(result.to_string(index=False))
    return result

# ── QUERY 1: Business Summary ──────────────────────────────────────
run_query("QUERY 1 — Overall Business Summary", """
    SELECT
        COUNT(DISTINCT order_id)       AS total_orders,
        ROUND(SUM(total_sale), 2)      AS total_revenue,
        ROUND(AVG(total_sale), 2)      AS avg_order_value,
        SUM(quantity)                  AS total_units_sold,
        ROUND(AVG(discount_pct), 1)    AS avg_discount_pct
    FROM sales
""")

# ── QUERY 2: Revenue by Category ──────────────────────────────────
run_query("QUERY 2 — Revenue by Category", """
    SELECT
        category,
        COUNT(order_id)                                          AS num_orders,
        SUM(quantity)                                            AS units_sold,
        ROUND(SUM(total_sale), 2)                               AS total_revenue,
        ROUND(SUM(total_sale) * 100.0 / SUM(SUM(total_sale))
              OVER (), 1)                                        AS revenue_share_pct
    FROM sales
    GROUP BY category
    ORDER BY total_revenue DESC
""")

# ── QUERY 3: Top 5 Products ────────────────────────────────────────
run_query("QUERY 3 — Top 5 Best-Selling Products", """
    SELECT
        product,
        category,
        SUM(quantity)              AS units_sold,
        ROUND(SUM(total_sale), 2)  AS total_revenue,
        ROUND(AVG(unit_price), 2)  AS avg_unit_price
    FROM sales
    GROUP BY product, category
    ORDER BY total_revenue DESC
    LIMIT 5
""")

# ── QUERY 4: Monthly Trend ─────────────────────────────────────────
run_query("QUERY 4 — Monthly Revenue Trend", """
    SELECT
        STRFTIME('%Y', date)      AS year,
        STRFTIME('%m', date)      AS month,
        COUNT(order_id)           AS num_orders,
        ROUND(SUM(total_sale),2)  AS monthly_revenue
    FROM sales
    GROUP BY year, month
    ORDER BY year, month
""")

# ── QUERY 5: Region Performance ───────────────────────────────────
run_query("QUERY 5 — Revenue by Region", """
    SELECT
        region,
        COUNT(DISTINCT order_id)      AS num_orders,
        ROUND(SUM(total_sale), 2)     AS total_revenue,
        ROUND(AVG(total_sale), 2)     AS avg_order_value
    FROM sales
    GROUP BY region
    ORDER BY total_revenue DESC
""")

# ── QUERY 6: Sales Rep Leaderboard ───────────────────────────────
run_query("QUERY 6 — Sales Rep Performance Leaderboard", """
    SELECT
        sales_rep,
        COUNT(order_id)            AS total_orders,
        ROUND(SUM(total_sale),2)   AS total_revenue,
        ROUND(AVG(total_sale),2)   AS avg_deal_size
    FROM sales
    GROUP BY sales_rep
    ORDER BY total_revenue DESC
""")

# ── QUERY 7: Year-over-Year ───────────────────────────────────────
run_query("QUERY 7 — Year-over-Year Comparison", """
    SELECT
        STRFTIME('%Y', date)       AS year,
        COUNT(order_id)            AS total_orders,
        ROUND(SUM(total_sale),2)   AS total_revenue,
        ROUND(AVG(total_sale),2)   AS avg_order_value
    FROM sales
    GROUP BY year
    ORDER BY year
""")

# ── QUERY 8: Discount Impact ──────────────────────────────────────
run_query("QUERY 8 — Discount Impact Analysis", """
    SELECT
        discount_pct,
        COUNT(order_id)            AS num_orders,
        ROUND(AVG(quantity),1)     AS avg_quantity,
        ROUND(AVG(total_sale),2)   AS avg_order_value,
        ROUND(SUM(total_sale),2)   AS total_revenue
    FROM sales
    GROUP BY discount_pct
    ORDER BY discount_pct
""")

# ── QUERY 9: Best Month per Region ───────────────────────────────
run_query("QUERY 9 — Best Month Per Region", """
    SELECT region, year, month, monthly_revenue
    FROM (
        SELECT
            region,
            STRFTIME('%Y', date)       AS year,
            STRFTIME('%m', date)       AS month,
            ROUND(SUM(total_sale),2)   AS monthly_revenue,
            RANK() OVER (
                PARTITION BY region
                ORDER BY SUM(total_sale) DESC
            ) AS rnk
        FROM sales
        GROUP BY region, year, month
    )
    WHERE rnk = 1
    ORDER BY monthly_revenue DESC
""")

# ── QUERY 10: High-Value Orders ───────────────────────────────────
run_query("QUERY 10 — High-Value Orders (2× Above Average)", """
    SELECT order_id, date, product, sales_rep, region, total_sale
    FROM sales
    WHERE total_sale > (SELECT AVG(total_sale) * 2 FROM sales)
    ORDER BY total_sale DESC
    LIMIT 10
""")

conn.close()
print("\n\n✅ All SQL queries executed successfully!\n")
